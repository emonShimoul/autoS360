<div class="slider-container rounded-2xl mb-8 mt-2">
  <div class="slider">
    <!-- <div class="slide" style="background-color: #ff6b6b;">Slide 1</div> -->
    <!-- <div class="slide" style="background-color: #6b8eff;">Slide 2</div>
    <div class="slide" style="background-color: #6bff9e;">Slide 3</div> -->

    <div class="slide">
      <img src="https://i.ibb.co.com/1b9n7C8/slider-1.jpg" alt="">
    </div>
    <div class="slide">
      <img src="https://i.ibb.co.com/s9nxRL2/slider-2.png" alt="">
    </div>
    <div class="slide">
      <img src="https://i.ibb.co.com/Yhj44Xb/slider-3.jpg" alt="">
    </div>
    <div class="slide">
      <img src="https://i.ibb.co.com/W2vn16Y/slider-4.jpg" alt="">
    </div>
  </div>
  <button class="prev-btn">❮</button>
  <button class="next-btn">❯</button>
</div>