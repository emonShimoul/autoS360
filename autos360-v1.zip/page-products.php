<?php
/*
Template Name: Products
*/
?>

<?php get_header(); ?>

<?php if(! is_front_page()){ ?>
<div class="">
    <h1 class="mx-20 py-48 text-center text-4xl text-blue-500">This is Product Page</h1>
</div>
<?php } ?>

<?php get_footer(); ?>