<?php get_header(); ?>

<?php get_template_part("slider"); ?>
<?php get_template_part("banner"); ?>
<?php get_template_part("services"); ?>
<?php get_template_part("testimonials"); ?>
<?php get_template_part("contact"); ?>

<?php get_footer(); ?>